package exercicio1_gft;

import java.util.Scanner;

public class Exercicio1_GFT {

    public static void main(String[] args) {

        int numero = 0;
        int soma = 0;

        Scanner entrada = new Scanner(System.in);

        while (soma <= 299) {
            System.out.println("--------------------------------");
            System.out.println("Informe um numero para a soma: ");
            numero = entrada.nextInt();
            if (numero < 0) {
                System.out.println("Numero negativos nao sao permitidos");
            } else {
                soma += numero;
            }
        }
        System.out.println("O somatorio foi " + soma);
    }

}
