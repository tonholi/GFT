package exercicio2_gft;

public class InvestimentoComIR extends Investimento {

    public InvestimentoComIR(double valorInicial, double jurosMensais, int meses) {
        this.valorInicial = 5000;
        this.jurosMensais = 0.012;
        this.meses = 17;
    }

    double desconto;

    public double calcularLucro(int meses) {
        if (meses > 6) {
            desconto = 0.225;
            double lucro;
            lucro = valorInicial * Math.pow(1 + jurosMensais, meses) - valorInicial;
            return lucro - desconto;
        } else if (meses <= 6 && meses > 12) {
            desconto = 0.2;
            double lucro;
            lucro = valorInicial * Math.pow(1 + jurosMensais, meses) - valorInicial;
            return lucro - desconto;
        } else if (meses <= 12 && meses >= 24) {
            desconto = 0.175;
            double lucro;
            lucro = valorInicial * Math.pow(1 + jurosMensais, meses) - valorInicial;
            return lucro - desconto;
        } else {
            desconto = 0.15;
            double lucro;
            lucro = valorInicial * Math.pow(1 + jurosMensais, meses) - valorInicial;
            return lucro - desconto;
        }

    }
}
