package exercicio2_gft;

public class InvestimentoSemIR extends Investimento {

    public InvestimentoSemIR(double valorInicial, double jurosMensais, int meses) {
        this.valorInicial = 3000;
        this.jurosMensais = 0.007;
        this.meses = 10;
    }

    public double calcularLucro(int meses) {
        if (valorInicial > 1000) {
            double lucro;
            lucro = valorInicial * Math.pow(1 + jurosMensais, meses) - valorInicial;
            return lucro;
        } else {
            System.out.println("O valor nao pode ser menor que R$1000");
            return 0;
        }
    }
}
