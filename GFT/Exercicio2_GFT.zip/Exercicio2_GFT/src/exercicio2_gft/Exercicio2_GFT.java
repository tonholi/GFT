package exercicio2_gft;

public class Exercicio2_GFT {

    public static void main(String[] args) {

        int tempo;

        InvestimentoComIR investimentoComIR = new InvestimentoComIR(5000, 0.012, 17);
        tempo = investimentoComIR.getMeses();
        System.out.println("O lucro do investimento com ir em valor inicial " + investimentoComIR.getValorInicial() + String.format("%.2f", investimentoComIR.calcularLucro(tempo));
        System.out.println("----------------------------------------------------------------");

        InvestimentoSemIR investimentoSemIR = new InvestimentoSemIR(3000, 0.07, 10);
        tempo = investimentoSemIR.getMeses();
        System.out.println("O lucro do investimento sem IR com valor inicial de  " + investimentoSemIR.getValorInicial() + " é: " + 
        String.format("%.2f", investimentoSemIR.calcularLucro(tempo));

    }

}
