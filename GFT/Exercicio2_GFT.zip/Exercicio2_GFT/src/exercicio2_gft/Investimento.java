package exercicio2_gft;

public class Investimento {
    
    double valorInicial;
    double jurosMensais;
    int meses;

    public void Investimento(double valorInicial, double jurosMensais, int meses) {
        this.valorInicial = valorInicial;
        this.jurosMensais = jurosMensais;
        this.meses = meses;
    }
    
    
                
    public int getMeses() {
        return meses;
    }

    public void setMeses(int meses) {
        this.meses = meses;
    }

    public double getValorInicial() {
        return valorInicial;
    }

    public void setValorInicial(double valorInicial) {
        this.valorInicial = valorInicial;
    }

    public double getJurosMensais() {
        return jurosMensais;
    }

    public void setJurosMensais(double jurosMensais) {
        this.jurosMensais = jurosMensais;
    }
    
    public double calcularLucro(int meses){
        double lucro;
        lucro = valorInicial * Math.pow(1 + jurosMensais,meses) - valorInicial;
        return lucro;
    }
    
    
}
